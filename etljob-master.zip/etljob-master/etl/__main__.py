from etl.job.etl_job import run_etl_job

if __name__ == "__main__":
    run_etl_job()
